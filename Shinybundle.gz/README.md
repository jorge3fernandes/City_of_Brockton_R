# City of Brockton - Fighting crime using Data Science

This project is focused on web scraping the Brockton Police wesitefor 911 call logs to identify opportunities to fight crimes.  
To get details on the analysis, please look into BPD_CallLog.Rmd.

######This is a work in progress, so feel free to contact me via email (jorge3fernandes@gmail.com) if you have some ideas that you'd like to discuss.
